# This file contains custom data types
# for input and output of critical endpoints.
# they derive from pydantic BaseModel

# class InputIrisData(BaseModel):
# class OutputIrisData(BaseModel):
from pydantic import BaseModel
from fastapi import FastAPI, File, UploadFile


class InputImageData(BaseModel):
    image: bytes


class OutputImageData(BaseModel):
    species: int
