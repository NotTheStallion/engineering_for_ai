# this file contains the services needed by your
# main application.
# get_or_train_model(): returns model
# predict_iris_species(parameters: input_data): returns int
# retrain_model()
import numpy as np
from model import predict, train_model
from persistence import load_model, save_model
import tensorflow as tf


def get_or_train_model():
    try:
        model = load_model()
    except FileNotFoundError:
        model, _ = train_model()
        save_model(model)
    return model


def predict_iris_species(input_data):
    model = get_or_train_model()
    input_data = tf.image.resize(input_data, [128, 128])
    input_data = input_data[:, :, :3]  # Remove the last channel
    result = predict(model, input_data)
    return int(result[0])


def retrain_model():
    model, accuracy = train_model()
    save_model(model)
    return accuracy
