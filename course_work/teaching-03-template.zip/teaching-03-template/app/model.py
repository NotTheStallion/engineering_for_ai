from sklearn import datasets
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from tensorflow.keras.applications import VGG16
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Flatten, Dropout, Flatten
import numpy as np
from tensorflow import keras
import os


def custom_model():
    inputs = keras.Input(shape=(128, 128, 3))
    layer = keras.applications.vgg16.preprocess_input(inputs)
    convolutional_part = keras.applications.vgg16.VGG16(
        weights="imagenet", include_top=False
    )
    convolutional_part.trainable = False
    layer = convolutional_part(layer)
    layer = Flatten()(layer)
    layer = Dropout(0.5)(layer)
    outputs = Dense(1, activation="relu")(layer)
    custom_model = keras.Model(inputs, outputs)
    return custom_model


def train_model():
    model = custom_model()

    model.compile(
        loss="binary_crossentropy", optimizer="rmsprop", metrics=["accuracy"]
    )

    base_dir = "/tmp/cats_and_dogs_filtered"
    train_dir = os.path.join(base_dir, "train")
    valid_dir = os.path.join(base_dir, "validation")
    
    train_datagen = ImageDataGenerator(rescale=0.2, validation_split=0.2)
    train_dataset = train_datagen.flow_from_directory(
        train_dir,
        target_size=(128, 128),
        batch_size=32,
        class_mode="binary",
        subset="training",
    )

    valid_dataset = train_datagen.flow_from_directory(
        valid_dir,
        target_size=(128, 128),
        batch_size=32,
        class_mode="binary",
        subset="validation",
    )

    callbacks = [
        keras.callbacks.ModelCheckpoint(
            filepath="model.keras", save_best_only=True, monitor="val_accuracy"
        )
    ]
    history = model.fit(
        train_dataset, epochs=10, validation_data=valid_dataset, callbacks=callbacks
    )

    return  model, history.history['accuracy'][-1]


def predict(model, input_data):
    input_data = np.expand_dims(input_data, axis=0)
    return model.predict(input_data)


if __name__ == "__main__":
    model = train_model()
    from persistence import save_model
    save_model(model)
    print(predict(model, np.random.rand(128, 128, 3)))
