# This file is the main file.
# It will contain your FastAPI code
# - initialization
# - endpoints for
#   - homepage (root)
#   - hello (heartbeat)
#   - predict(parameters: input_features)
#   - train
# - code to start server
# - NOTE - you will need to create data types for input and output of critical endpoints

from datetime import datetime

import uvicorn
from fastapi import FastAPI
from fastapi import FastAPI, File, UploadFile
from schemas import InputImageData, OutputImageData
from services import predict_iris_species, retrain_model
from PIL import Image
from io import BytesIO
import numpy as np
import tensorflow as tf




app = FastAPI()

def read_imagefile(data) -> Image.Image:
    image = Image.open(BytesIO(data))
    return image


@app.get("/")
async def root():
    """Simple message for homepage."""
    return {"message": "Welcome!"}


@app.get("/hello")
async def hello():
    """Returns heartbeat with timestamp."""
    return {"message": f"{datetime.now():%Y-%m-%d %H:%M:%S.%f}"}


@app.post("/predict_iris_species", response_model=OutputImageData)
async def predict_species(data: UploadFile = File(...)):
    image = read_imagefile(await data.read())
    print("="*10,image)
    image = tf.keras.utils.img_to_array(image)
    print("="*10,image)
    species = predict_iris_species(image)
    return {"species": species}


@app.post("/train_iris")
async def train_iris():
    accuracy = retrain_model()
    return {"accuracy": accuracy}


if __name__ == "__main__":
    print("Starting FastAPI")
    uvicorn.run("main:app", host="0.0.0.0", port=5000)
